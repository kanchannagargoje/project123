let x=20;
    let y=30;
    let z=(x+y);
    console.log(z);